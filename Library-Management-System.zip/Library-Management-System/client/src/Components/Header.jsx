import { Bell, CalendarDays, Check, Menu } from "lucide-react";
import { useEffect, useRef, useState } from "react";

function Header({ title, mobile, setMobile, notifications = [], onMarkRead, onMarkAllRead }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const unreadCount = notifications.filter((item) => !item.read).length;
  useEffect(() => {
    function closeOnOutsideClick(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) setOpen(false);
    }
    document.addEventListener("mousedown", closeOnOutsideClick);
    return () => document.removeEventListener("mousedown", closeOnOutsideClick);
  }, []);
  const today = new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(new Date());

  return (
    <header className="top">
      <div className="top-left">
        <button
          className="hamb"
          aria-label="Open navigation menu"
          aria-expanded={mobile}
          onClick={() => setMobile(true)}
        >
          <Menu />
        </button>
        <span>Workspace</span>
        <b>/</b>
        <strong>{title}</strong>
      </div>
      <div className="top-right">
        <div className="date"><CalendarDays size={15} /> {today}</div>
        <div className="notification-menu" ref={menuRef}>
        <button className="bell" aria-label="Show notifications" aria-expanded={open} onClick={() => setOpen((value) => !value)}>
          <Bell size={18} />
          {unreadCount > 0 && <span className="notification-badge">{unreadCount > 99 ? "99+" : unreadCount}</span>}
        </button>
        {open && <section className="notification-dropdown" aria-label="Notifications">
          <div className="notification-heading">
            <div><strong>Notifications</strong><span>{notifications.length} total</span></div>
            {unreadCount > 0 && <button onClick={onMarkAllRead}>Mark all read</button>}
          </div>
          <div className="notification-list">
            {notifications.length === 0 ? <p className="notification-empty">You’re all caught up.</p> : [...notifications].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map((item) => (
              <button className={`notification-item${item.read ? " is-read" : " is-unread"}`} key={item.id} onClick={() => onMarkRead?.(item.id)}>
                <span className="notification-dot" />
                <span className="notification-content"><strong>{item.title}</strong><span>{item.message}</span><time>{new Date(item.createdAt).toLocaleString()}</time></span>
                {!item.read && <Check size={15} aria-label="Mark as read" />}
              </button>
            ))}
          </div>
        </section>}
        </div>
        <div className="avatar">LI</div>
      </div>
    </header>
  );
}

export default Header;
