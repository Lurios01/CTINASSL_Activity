import {
  ArrowLeftRight,
  BookOpen,
  ChartNoAxesCombined,
  ChevronDown,
  LayoutDashboard,
  LibraryBig,
  ListOrdered,
  MoreHorizontal,
  Users,
  X,
} from "lucide-react";

const navigation = [
  ["Overview", LayoutDashboard],
  ["Book collection", BookOpen],
  ["Indexing", ListOrdered],
  ["Members", Users],
  ["Circulation", ArrowLeftRight],
  ["Insights", ChartNoAxesCombined],
];

function Sidebar({ activePage, setActivePage, mobile, setMobile, activeCount }) {
  return (
    <aside className={`sidebar ${mobile ? "show" : ""}`}>
      <div className="logo">
        <div className="logoicon"><LibraryBig /></div>
        <div>
          <b>Leaf Library</b>
          <small>LIBRARY WORKSPACE</small>
        </div>
        <button className="closemobile" aria-label="Close menu" onClick={() => setMobile(false)}>
          <X />
        </button>
      </div>

      <div className="branch">
        <div className="branchseal">LL</div>
        <div>
          <b>NU Learning Commons</b>
          <small>Manila · Main branch</small>
        </div>
        <ChevronDown size={15} />
      </div>

      <div className="navlabel">WORKSPACE</div>
      <nav aria-label="Main navigation">
        {navigation.map(([name, Icon]) => (
          <button
            key={name}
            aria-current={activePage === name ? "page" : undefined}
            onClick={() => {
              setActivePage(name);
              setMobile(false);
            }}
            className={activePage === name ? "active" : ""}
          >
            <Icon size={18} />
            {name}
            {name === "Circulation" && <span className="navcount">{activeCount}</span>}
          </button>
        ))}
      </nav>

      <div className="sidebottom">
        <div className="user">
          <div className="avatar dark">LI</div>
          <div>
            <b>Library Admin</b>
            <small>Administrator</small>
          </div>
          <MoreHorizontal size={18} />
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;
