import "dotenv/config";
import express from "express";
import mongoose from "mongoose";

const app = express();
const port = Number(process.env.PORT) || 5000;
const collections = ["books", "members", "loans", "notifications"];

const makeRecordSchema = () =>
  new mongoose.Schema(
    {
      key: { type: String, required: true, unique: true },
      position: { type: Number, required: true },
      data: { type: mongoose.Schema.Types.Mixed, required: true },
    },
    { versionKey: false },
  );

const BookRecord = mongoose.model("BookRecord", makeRecordSchema(), "books");
const MemberRecord = mongoose.model("MemberRecord", makeRecordSchema(), "members");
const NotificationRecord = mongoose.model(
  "NotificationRecord",
  makeRecordSchema(),
  "notifications",
);
const loanSchema = new mongoose.Schema(
  {
    key: { type: String, required: true, unique: true },
    position: { type: Number, required: true },
    data: { type: mongoose.Schema.Types.Mixed, required: true },
    bookRef: { type: mongoose.Schema.Types.ObjectId, ref: "BookRecord", default: null, index: true },
    memberRef: { type: mongoose.Schema.Types.ObjectId, ref: "MemberRecord", default: null, index: true },
  },
  { versionKey: false },
);
const LoanRecord = mongoose.model("LoanRecord", loanSchema, "loans");
const recordKey = (id) => JSON.stringify([typeof id, id]);

async function replaceRecords(model, items, extraFields = () => ({})) {
  const keys = items.map((item) => recordKey(item.id));
  if (items.length) {
    await model.bulkWrite(
      items.map((item, position) => ({
        updateOne: {
          filter: { key: recordKey(item.id) },
          update: {
            $set: { data: item, position, ...extraFields(item) },
          },
          upsert: true,
        },
      })),
    );
  }
  await model.deleteMany({ key: { $nin: keys } });
}
const metadataSchema = new mongoose.Schema(
  { key: { type: String, required: true, unique: true }, initialized: Boolean },
  { versionKey: false },
);
const LibraryMetadata = mongoose.model("LibraryMetadata", metadataSchema, "library_metadata");

app.use(express.json({ limit: "48mb" }));

app.get("/api/health", (_request, response) => {
  response.json({ database: mongoose.connection.readyState === 1 ? "connected" : "disconnected" });
});

app.get("/api/library", async (_request, response) => {
  try {
    const [metadata, books, members, loans, notifications] = await Promise.all([
      LibraryMetadata.findOne({ key: "main" }).lean(),
      BookRecord.find().sort({ position: 1 }).lean(),
      MemberRecord.find().sort({ position: 1 }).lean(),
      LoanRecord.find()
        .sort({ position: 1 })
        .populate("bookRef", "data")
        .populate("memberRef", "data")
        .lean(),
      NotificationRecord.find().sort({ position: 1 }).lean(),
    ]);
    const data = {
      books: books.map((entry) => entry.data),
      members: members.map((entry) => entry.data),
      loans: loans.map((entry) => ({
        ...entry.data,
        bookId: entry.bookRef?.data?.id ?? entry.data.bookId,
        memberId: entry.memberRef?.data?.id ?? entry.data.memberId,
      })),
      notifications: notifications.map((entry) => entry.data),
    };
    response.json({ initialized: Boolean(metadata?.initialized), data });
  } catch (error) {
    console.error("Failed to load library data:", error);
    response.status(500).json({ error: "Failed to load library data." });
  }
});

app.put("/api/library", async (request, response) => {
  const data = request.body;
  if (
    !data ||
    collections.some((collection) => !Array.isArray(data[collection]))
  ) {
    return response.status(400).json({ error: "All library collections must be arrays." });
  }

  for (const collection of collections) {
    const ids = new Set();
    for (const item of data[collection]) {
      if (
        !item ||
        typeof item !== "object" ||
        !["string", "number"].includes(typeof item.id) ||
        item.id === ""
      ) {
        return response.status(400).json({ error: `Each ${collection} record must have a string or numeric id.` });
      }
      const key = recordKey(item.id);
      if (ids.has(key)) {
        return response.status(400).json({ error: `Duplicate id in ${collection}.` });
      }
      ids.add(key);
    }
  }

  try {
    await Promise.all([
      replaceRecords(BookRecord, data.books),
      replaceRecords(MemberRecord, data.members),
      replaceRecords(NotificationRecord, data.notifications),
    ]);
    const [books, members] = await Promise.all([
      BookRecord.find({}, "_id key").lean(),
      MemberRecord.find({}, "_id key").lean(),
    ]);
    const bookRefs = new Map(books.map((book) => [book.key, book._id]));
    const memberRefs = new Map(members.map((member) => [member.key, member._id]));
    await replaceRecords(LoanRecord, data.loans, (loan) => ({
      bookRef: bookRefs.get(recordKey(loan.bookId)) ?? null,
      memberRef: memberRefs.get(recordKey(loan.memberId)) ?? null,
    }));
    await LibraryMetadata.updateOne(
      { key: "main" },
      { $set: { initialized: true } },
      { upsert: true },
    );
    response.json({ saved: true });
  } catch (error) {
    console.error("Failed to save library data:", error);
    response.status(500).json({ error: "Failed to save library data." });
  }
});

async function startServer() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI is missing. Set it in server/.env.");
  }
  await mongoose.connect(uri);
  app.listen(port, "127.0.0.1", () => {
    console.log(`Library API connected to MongoDB and listening on http://127.0.0.1:${port}`);
  });
}

startServer().catch((error) => {
  console.error("Could not start the library API:", error.message);
  process.exitCode = 1;
});
