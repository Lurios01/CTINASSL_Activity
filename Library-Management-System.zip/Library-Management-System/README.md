# Leaf Library

The app stores its library catalog, member list, loans, and notifications in the `leaf_library` MongoDB database through the API in `server/`. The corresponding collections are `books`, `members`, `loans`, and `notifications`.

## Run locally

1. Install and start MongoDB locally, or create a MongoDB Atlas database.
2. In `server/`, copy `.env.example` to `.env` and set `MONGODB_URI` to your MongoDB connection string.
3. Install and start the API:

   ```powershell
   cd server
   npm install
   npm run dev
   ```

4. In another terminal, install and start the client:

   ```powershell
   cd client
   npm install
   npm run dev
   ```

Open the Vite URL shown in the client terminal. The Vite development server forwards `/api` requests to the API on port 5000. The API binds to localhost only.

On the first launch, the app imports existing browser-saved data, or its demo catalog if no browser data exists, into MongoDB. Data is subsequently loaded from and saved to the database. Keep `server/.env` private.

The current administrator sign-in is still the app's local demo authentication; MongoDB persistence does not change or secure that login.

## Data relationships

- One book can have many loan records. Each loan stores a MongoDB `bookRef` pointing to `books._id`.
- One member can have many loan records. Each loan stores a MongoDB `memberRef` pointing to `members._id`.
- Loan `data.bookId` and `data.memberId` remain for the existing client API; the API populates the MongoDB references when loading loan data.
- References are nullable so historical loans remain available if a related book or member is removed.
